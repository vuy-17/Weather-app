#Weather app



This app is created using HTML,CSS,Javascript,NodeJs

Run using:

>nodemon index.js  
